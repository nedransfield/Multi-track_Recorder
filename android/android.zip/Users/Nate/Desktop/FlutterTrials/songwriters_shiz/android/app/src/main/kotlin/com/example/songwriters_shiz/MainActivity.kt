package com.example.songwriters_shiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
